
@FunctionalInterface
public interface Summation {
	public String getMessage(String message);
}
