package org.shopping.entity;

public enum ProductTypeCategory {
  A,B,C,D,E;
		
}
