
public class AdditionImpl2 implements Addition {

	@Override
	public void hi() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hello() {
		// TODO Auto-generated method stub
		
	}

}
